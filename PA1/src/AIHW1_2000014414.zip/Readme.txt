Elements of Artificial Intelligence - Programming assignment -1

Submitters: Naveenkumar Ramaraju & Gowtham Ayna Raveendran



Launch or key file - aihw1.py
Distance Input format - csv. (‘distance.cv’ was the file used for testing)
Output pdf - AIHW-PA1-Output


Files:
AIHW-PA1-Outputaihw1.pyBreadth_First_Finder.pyBreadth_First_Finder.pycDepth_First_Finder.pyDepth_First_Finder.pycdistanceDistance.pyDistance.pycDistanceFinder.pyDistanceFinder.pycIterative_Depth_Finder.pyIterative_Depth_Finder.pyclocation.pylocation.pyc